local M = {}

local SETTINGS_FILE = "/settings/CodexAutopilot.json"
local MESSAGE_CATEGORY = "codexAutopilot"
local ARRIVAL_DISTANCE = 12
local ARRIVAL_ROUTE_DISTANCE = 14
local UI_UPDATE_INTERVAL = 0.25
local MAX_FIXED_SPEED_KMH = 500
local STOP_SPEED_THRESHOLD = 0.45
local STOP_TIMEOUT = 12
local STOP_REISSUE_INTERVAL = 1.25
local FORCE_PARK_MAX_SPEED = 2
local OVERTAKE_TRIGGER_TIME = 0.25
local OVERTAKE_CLEAR_TIME = 2.5
local OVERTAKE_MAX_TIME = 18
local OVERTAKE_MIN_HOLD_TIME = 4.5
local OVERTAKE_PASS_CLEAR_FORWARD = -12
local OVERTAKE_TRACK_MAX_FORWARD = 120
local OVERTAKE_REISSUE_INTERVAL = 0.45
local OVERTAKE_DEFAULT_SIDE = -1
local BLOCKING_OBSTACLE_SPEED = 1.6
local BLOCKING_OBSTACLE_FORWARD = 75
local BLOCKING_OBSTACLE_LATERAL = 3.35
local SAME_LANE_LATERAL = 2.15
local DIRECT_THREAT_LATERAL = 1.85
local CUTIN_THREAT_FORWARD = 55
local CUTIN_THREAT_TIME = 2.35
local CUTIN_LATERAL_SPEED = 1.1
local HIGHBEAM_FLASH_RANGE = 18
local TRAFFIC_HORN_RANGE = 13
local TRAFFIC_HORN_REPEAT = 3.6
local TRAFFIC_HORN_PULSE = 0.22
local TRAFFIC_HORN_GAP = 0.14
local SLOW_RECOVERY_TIME = 2.4

local DEFAULT_SETTINGS = {
  enabled = true,
  hudVisible = true,
  drivingMode = "normal",
  speedMode = "adaptive",
  fixedSpeedKmh = 80,
  aggression = 0.3,
  avoidCars = true,
  driveInLane = true,
  overtakeTraffic = true,
  clearRouteOnStop = false
}

local TEXT = {
  en = {
    autopilotStarted = "Autopilot started",
    autopilotStopped = "Autopilot stopped",
    autopilotArrived = "Autopilot arrived",
    disabled = "Autopilot is disabled in settings",
    noVehicle = "Autopilot: no player vehicle",
    noRoute = "Autopilot: set a route on the map first",
    noAiRoute = "Autopilot: could not build an AI route"
  },
  ru = {
    autopilotStarted = "Автопилот запущен",
    autopilotStopped = "Автопилот остановлен",
    autopilotArrived = "Автопилот прибыл",
    disabled = "Автопилот отключен в настройках",
    noVehicle = "Автопилот: нет машины игрока",
    noRoute = "Автопилот: сначала поставь маршрут на карте",
    noAiRoute = "Автопилот: не удалось построить маршрут для AI"
  }
}

local state = {
  settings = nil,
  active = false,
  vehicleId = nil,
  destinationPos = nil,
  status = "idle",
  uiTimer = 0,
  lastSignature = nil,
  stopping = false,
  stopTimer = 0,
  stopCommandTimer = 0,
  stopClearRoute = false,
  stopSilent = false,
  stopMessage = nil,
  stopFinalStatus = "stopped",
  emergencyBrake = false,
  lastRouteDistance = nil,
  routeRecovering = false,
  routeRecoverTimer = 0,
  routeStallTimer = 0,
  highBeamFlash = {
    timer = 0,
    pulseOn = false
  },
  trafficHorn = {
    timer = 0,
    pulseOn = false
  },
  slowRecoveryTimer = 0,
  overtakeAssist = {
    active = false,
    timer = 0,
    clearTimer = 0,
    age = 0,
    commandTimer = 0,
    blockerId = nil,
    side = OVERTAKE_DEFAULT_SIDE,
    lastBlockerForward = nil,
    blocking = false
  }
}

local function clamp(value, low, high)
  value = tonumber(value) or low
  return math.min(high, math.max(low, value))
end

local function copyTable(source)
  local result = {}
  for key, value in pairs(source or {}) do
    result[key] = value
  end
  return result
end

local function sanitizeSettings(candidate)
  candidate = type(candidate) == "table" and candidate or {}

  return {
    enabled = candidate.enabled ~= false,
    hudVisible = candidate.hudVisible ~= false,
    drivingMode = candidate.drivingMode == "aggressive" and "aggressive" or "normal",
    speedMode = candidate.speedMode == "fixed" and "fixed" or "adaptive",
    fixedSpeedKmh = clamp(candidate.fixedSpeedKmh, 5, MAX_FIXED_SPEED_KMH),
    aggression = clamp(candidate.aggression, 0.2, 2),
    avoidCars = candidate.avoidCars ~= false,
    driveInLane = candidate.driveInLane ~= false,
    overtakeTraffic = candidate.overtakeTraffic ~= false,
    clearRouteOnStop = candidate.clearRouteOnStop == true
  }
end

local function getSettings()
  if not state.settings then
    state.settings = sanitizeSettings(jsonReadFile(SETTINGS_FILE) or DEFAULT_SETTINGS)
  end
  return state.settings
end

local function saveSettings()
  state.settings = sanitizeSettings(state.settings)
  jsonWriteFile(SETTINGS_FILE, state.settings, true)
end

local function getLocale()
  if settings and settings.getValue then
    local ok, language = pcall(function()
      return settings.getValue("uiLanguage") or settings.getValue("userLanguageSelected") or settings.getValue("userLanguage")
    end)
    if ok and language and language ~= "" then return language end
  end

  if Lua and Lua.getSelectedLanguage then
    local ok, language = pcall(function() return Lua:getSelectedLanguage() end)
    if ok and language then return language end
  end
  return "en-US"
end

local function getLanguageKey()
  local locale = string.lower(tostring(getLocale() or "en-US"))
  return string.sub(locale, 1, 2) == "ru" and "ru" or "en"
end

local function tr(key)
  local language = getLanguageKey()
  return (TEXT[language] and TEXT[language][key]) or TEXT.en[key] or tostring(key)
end

local function message(key, category)
  ui_message(tr(key), 5, MESSAGE_CATEGORY, category or "info")
end

local function resetOvertakeAssist()
  state.overtakeAssist.active = false
  state.overtakeAssist.timer = 0
  state.overtakeAssist.clearTimer = 0
  state.overtakeAssist.age = 0
  state.overtakeAssist.commandTimer = 0
  state.overtakeAssist.blockerId = nil
  state.overtakeAssist.side = OVERTAKE_DEFAULT_SIDE
  state.overtakeAssist.lastBlockerForward = nil
  state.overtakeAssist.blocking = false
end

local function getPlayerVehicle()
  return be and be:getPlayerVehicle(0) or nil
end

local function getRoutePlanner()
  if not core_groundMarkers or not core_groundMarkers.currentlyHasTarget then
    return nil
  end

  if not core_groundMarkers.currentlyHasTarget() then
    return nil
  end

  local routePlanner = core_groundMarkers.routePlanner
  if not routePlanner or not routePlanner.path or not routePlanner.path[2] then
    return nil
  end

  return routePlanner
end

local function getRouteInfo()
  local routePlanner = getRoutePlanner()
  if not routePlanner then
    return {
      hasRoute = false,
      routeDistance = 0,
      routeNodes = 0
    }
  end

  local path = routePlanner.path
  local last = path[#path]
  local distance = path[1].distToTarget or routePlanner:calcDistance() or 0

  return {
    hasRoute = true,
    routeDistance = distance,
    routeNodes = #path,
    destination = last and last.pos and {x = last.pos.x, y = last.pos.y, z = last.pos.z} or nil
  }
end

local function hasArrivedAtDestination(veh, routeInfo)
  if not veh or not state.destinationPos or not routeInfo or not routeInfo.hasRoute then return false end
  if (routeInfo.routeDistance or math.huge) > ARRIVAL_ROUTE_DISTANCE then return false end
  return veh:getPosition():distance(state.destinationPos) <= ARRIVAL_DISTANCE
end

local function getUiState()
  local routeInfo = getRouteInfo()
  local vehicle = getPlayerVehicle()

  return {
    settings = getSettings(),
    active = state.active,
    stopping = state.stopping,
    status = state.status,
    hasRoute = routeInfo.hasRoute,
    routeDistance = routeInfo.routeDistance,
    routeNodes = routeInfo.routeNodes,
    destination = routeInfo.destination,
    vehicleId = vehicle and vehicle:getID() or nil,
    locale = getLocale()
  }
end

local function triggerUiState()
  guihooks.trigger("CodexAutopilotStateChanged", getUiState())
end

local function buildRouteSignature()
  local uiState = getUiState()
  local dest = uiState.destination
  local destKey = "none"
  if dest then
    destKey = string.format("%.1f:%.1f:%.1f", dest.x or 0, dest.y or 0, dest.z or 0)
  end

  return table.concat({
    tostring(uiState.active),
    tostring(uiState.stopping),
    tostring(uiState.status),
    tostring(uiState.hasRoute),
    tostring(uiState.vehicleId),
    tostring(uiState.routeNodes),
    tostring(math.floor((uiState.routeDistance or 0) + 0.5)),
    destKey
  }, "|")
end

local function getAiPath(path, veh)
  local aiPath = {}
  if not veh or not path then return nil end

  local firstWpAdded = false
  local vehPos = veh:getPosition()
  local vehFwd = veh:getDirectionVector()
  local prevDot = nil
  local prevWp = nil
  local startDist = path[1].distToTarget or 0

  for i, marker in ipairs(path) do
    if marker.wp then
      if not firstWpAdded then
        local toWp = marker.pos - vehPos
        if toWp:squaredLength() > 0.01 then
          toWp:normalize()
          local dot = toWp:dot(vehFwd)
          if prevDot and dot < prevDot and prevDot > 0 then
            table.insert(aiPath, prevWp)
            firstWpAdded = true
          end
          prevDot = dot
          prevWp = marker.wp
        end
      else
        table.insert(aiPath, marker.wp)
      end
    end
  end

  if not firstWpAdded and prevDot and prevDot > 0 and prevWp then
    table.insert(aiPath, prevWp)
    firstWpAdded = true
  end

  if not firstWpAdded then
    for _, marker in ipairs(path) do
      if marker.wp and startDist - (marker.distToTarget or 0) > 25 then
        table.insert(aiPath, marker.wp)
      end
    end
  end

  local compact = {}
  local lastWp = nil
  for _, wp in ipairs(aiPath) do
    if wp and wp ~= lastWp then
      table.insert(compact, wp)
      lastWp = wp
    end
  end

  return compact[1] and compact or nil
end

local function queueAiStop(veh)
  if veh then
    veh:queueLuaCommand('ai.setSpeedMode("set"); ai.setSpeed(0); ai.setState({mode = "stop"})')
  end
end

local function parkVehicleAndDisableAi(veh)
  if veh then
    veh:queueLuaCommand(
      'ai.setState({mode = "disabled"}); input.event("steering", 0, "FILTER_AI", nil, nil, nil, "ai"); input.event("throttle", 0, "FILTER_AI", nil, nil, nil, "ai"); input.event("brake", 0, "FILTER_AI", nil, nil, nil, "ai"); input.event("parkingbrake", 1, "FILTER_AI", nil, nil, nil, "ai")'
    )
  end
end

local function releaseAiParkingBrake(veh)
  if veh then
    veh:queueLuaCommand('input.event("brake", 0, "FILTER_AI", nil, nil, nil, "ai"); input.event("parkingbrake", 0, "FILTER_AI", nil, nil, nil, "ai")')
  end
end

local function setHighBeamFlash(veh, enabled)
  if not veh then return end
  if enabled and not state.highBeamFlash.pulseOn then
    state.highBeamFlash.pulseOn = true
    veh:queueLuaCommand("electrics.light_flash_highbeams(true)")
  elseif not enabled and state.highBeamFlash.pulseOn then
    state.highBeamFlash.pulseOn = false
    veh:queueLuaCommand("electrics.light_flash_highbeams(false)")
  end
end

local function stopHighBeamFlash(veh)
  state.highBeamFlash.timer = 0
  setHighBeamFlash(veh, false)
end

local function setTrafficHorn(veh, enabled)
  if not veh then return end
  if enabled and not state.trafficHorn.pulseOn then
    state.trafficHorn.pulseOn = true
    veh:queueLuaCommand("electrics.horn(true)")
  elseif not enabled and state.trafficHorn.pulseOn then
    state.trafficHorn.pulseOn = false
    veh:queueLuaCommand("electrics.horn(false)")
  end
end

local function stopTrafficHorn(veh)
  state.trafficHorn.timer = 0
  setTrafficHorn(veh, false)
end

local function updateHighBeamFlash(veh, shouldFlash, dtReal)
  if not shouldFlash then
    stopHighBeamFlash(veh)
    return
  end

  state.highBeamFlash.timer = state.highBeamFlash.timer + (dtReal or 0)
  local cycle = state.highBeamFlash.timer % 3.2
  local pulse = cycle < 1.25 and (math.floor(cycle / 0.22) % 2 == 0)
  setHighBeamFlash(veh, pulse)
end

local function updateTrafficHorn(veh, shouldHonk, dtReal)
  if not shouldHonk then
    stopTrafficHorn(veh)
    return
  end

  state.trafficHorn.timer = state.trafficHorn.timer + (dtReal or 0)
  local cycle = state.trafficHorn.timer % TRAFFIC_HORN_REPEAT
  local firstPulseEnd = TRAFFIC_HORN_PULSE
  local secondPulseStart = TRAFFIC_HORN_PULSE + TRAFFIC_HORN_GAP
  local secondPulseEnd = secondPulseStart + TRAFFIC_HORN_PULSE
  local pulse = cycle < firstPulseEnd or (cycle > secondPulseStart and cycle < secondPulseEnd)
  setTrafficHorn(veh, pulse)
end

local function clearNavigationRoute()
  if freeroam_bigMapMode and freeroam_bigMapMode.setNavFocus then
    freeroam_bigMapMode.setNavFocus(nil)
  elseif core_groundMarkers and core_groundMarkers.setPath then
    core_groundMarkers.setPath(nil)
  end
end

local function recoverNavigationRoute()
  if not state.destinationPos or not core_groundMarkers or not core_groundMarkers.setPath then return false end
  core_groundMarkers.setPath(vec3(state.destinationPos))
  if not state.routeRecovering then
    state.routeRecoverTimer = 0
  end
  state.routeRecovering = true
  return true
end

local function finishStop(veh)
  stopHighBeamFlash(veh)
  stopTrafficHorn(veh)
  parkVehicleAndDisableAi(veh)
  state.active = false
  state.stopping = false
  state.vehicleId = nil
  state.destinationPos = nil
  state.stopTimer = 0
  state.stopCommandTimer = 0
  state.emergencyBrake = false
  state.lastRouteDistance = nil
  state.routeRecovering = false
  state.routeRecoverTimer = 0
  state.routeStallTimer = 0
  state.slowRecoveryTimer = 0
  resetOvertakeAssist()
  state.status = state.stopFinalStatus or "stopped"

  if state.stopClearRoute or getSettings().clearRouteOnStop then
    clearNavigationRoute()
  end

  if not state.stopSilent and state.stopMessage then
    message(state.stopMessage)
  end

  state.stopClearRoute = false
  state.stopSilent = false
  state.stopMessage = nil
  state.stopFinalStatus = "stopped"
end

local function beginStop(clearRoute, silent, status, stopMessage, finalStatus)
  local veh = state.vehicleId and getObjectByID(state.vehicleId) or getPlayerVehicle()
  state.active = false
  state.stopping = true
  state.stopTimer = 0
  state.stopCommandTimer = 0
  state.stopClearRoute = clearRoute == true
  state.stopSilent = silent == true
  state.stopMessage = stopMessage
  state.stopFinalStatus = finalStatus or "stopped"
  state.status = status or "stopping"

  if veh then
    stopHighBeamFlash(veh)
    stopTrafficHorn(veh)
    queueAiStop(veh)
  else
    finishStop(nil)
    state.status = "noVehicle"
  end

  triggerUiState()
  return getUiState()
end

local function stopAutopilot(clearRoute, silent)
  if state.stopping then
    return getUiState()
  end

  return beginStop(clearRoute, silent, "stopping", "autopilotStopped")
end

local startAutopilot

local function getDrivingProfile(settings)
  local aggressive = settings.drivingMode == "aggressive"

  if aggressive then
    return {
      aggressive = true,
      racing = true,
      aggression = math.max(settings.aggression, 1.75),
      avoidCars = "on",
      driveInLane = "off",
      routeSpeedMode = "set",
      routeSpeed = ((settings.speedMode == "fixed" and settings.fixedSpeedKmh) or MAX_FIXED_SPEED_KMH) / 3.6,
      parameters = {
        minStTargetDist = 0.8,
        trafficWaitTime = 0,
        awarenessForceCoef = 1.15,
        edgeDist = -2.2,
        lookAheadKv = 0.9,
        throttleKp = 0.95,
        targetSpeedSmootherRate = 25,
        staticFrictionCoefMult = 1,
        turnForceCoef = 1.65
      }
    }
  end

  return {
    aggressive = false,
    racing = false,
    aggression = settings.aggression,
    avoidCars = settings.avoidCars and "on" or "off",
    driveInLane = settings.driveInLane and "on" or "off",
    routeSpeedMode = settings.speedMode == "fixed" and "limit" or "legal",
    routeSpeed = settings.speedMode == "fixed" and settings.fixedSpeedKmh / 3.6 or nil,
    parameters = {
      minStTargetDist = 3.5,
      trafficWaitTime = 0.4,
      awarenessForceCoef = 0.85,
      edgeDist = -0.25,
      lookAheadKv = 0.45,
      throttleKp = 0.35,
      targetSpeedSmootherRate = 5,
      staticFrictionCoefMult = 0.82,
      turnForceCoef = 2.2
    }
  }
end

local function applyDrivingProfile(veh, profile)
  if not veh or not profile then return end

  veh:queueLuaCommand("ai.setRacing(" .. tostring(profile.racing == true) .. ")")
  veh:queueLuaCommand("ai.setTrafficFilter(" .. tostring(profile.racing ~= true) .. ")")
  veh:queueLuaCommand("ai.setAggression(" .. tostring(profile.aggression) .. ")")
  veh:queueLuaCommand('ai.setAvoidCars("' .. profile.avoidCars .. '")')
  veh:queueLuaCommand('ai.driveInLane("' .. profile.driveInLane .. '")')
  veh:queueLuaCommand("ai.setParameters(" .. serialize(profile.parameters) .. ")")
  veh:queueLuaCommand('ai.setSpeedMode("' .. profile.routeSpeedMode .. '")')
  if profile.routeSpeed then
    veh:queueLuaCommand("ai.setSpeed(" .. tostring(profile.routeSpeed) .. ")")
  end
end

local function vecLength(v)
  if not v then return 0 end
  return (v.length and v:length()) or (v.len and v:len()) or 0
end

local function getPreferredOvertakeSide()
  if mapmgr and mapmgr.rules and mapmgr.rules.rightHandDrive ~= nil then
    return mapmgr.rules.rightHandDrive and -1 or 1
  end

  return OVERTAKE_DEFAULT_SIDE
end

local function getPassSideFromLateral(signedLateral)
  if signedLateral and signedLateral > 0.45 then return -1 end
  if signedLateral and signedLateral < -0.45 then return 1 end
  return getPreferredOvertakeSide()
end

local function choosePassSide(blockerId, signedLateral, egoPos, egoDir, egoRight, forward)
  if signedLateral and signedLateral > 0.9 then return -1 end
  if signedLateral and signedLateral < -0.9 then return 1 end
  if not map or not map.objects then return getPassSideFromLateral(signedLateral) end

  local leftScore = 0
  local rightScore = 0
  local maxForward = math.max((forward or 0) + 28, 45)
  for id, data in pairs(map.objects) do
    if id ~= state.vehicleId and id ~= blockerId and data and data.pos then
      local rel = data.pos - egoPos
      local otherForward = rel:dot(egoDir)
      if otherForward > -8 and otherForward < maxForward then
        local otherLateral = rel:dot(egoRight)
        local weight = 1 / math.max(8, math.abs(otherForward - (forward or 0)))
        if otherLateral < -0.6 then
          leftScore = leftScore + weight
        elseif otherLateral > 0.6 then
          rightScore = rightScore + weight
        end
      end
    end
  end

  if leftScore < rightScore then return -1 end
  if rightScore < leftScore then return 1 end
  return getPreferredOvertakeSide()
end

local function getOvertakeSpeed(settings, blocker)
  local aggressive = settings.drivingMode == "aggressive"
  if blocker and blocker.blocking then
    local capKmh = aggressive and 70 or 45
    if settings.speedMode == "fixed" then
      capKmh = math.min(settings.fixedSpeedKmh, aggressive and 90 or 60)
    end
    return capKmh / 3.6
  end

  local capKmh = aggressive and 145 or 100
  if settings.speedMode == "fixed" then
    capKmh = math.min(settings.fixedSpeedKmh, aggressive and 190 or 125)
  end

  local blockerKmh = math.max(0, ((blocker and blocker.otherLongSpeed) or 0) * 3.6)
  local desiredKmh = math.max(aggressive and 95 or 65, blockerKmh + (aggressive and 45 or 30))
  return clamp(desiredKmh, 8, math.max(8, capKmh)) / 3.6
end

local function applyOvertakeProfile(veh, settings, blocker)
  if not veh then return end

  local aggressive = settings.drivingMode == "aggressive"
  local aggression = aggressive and math.max(settings.aggression, 1.65) or math.max(settings.aggression, 0.65)
  local blocking = blocker and blocker.blocking
  local passSide = state.overtakeAssist.side or (blocker and blocker.passSide) or getPreferredOvertakeSide()
  local laneChangeDisp = passSide * (blocking and (aggressive and 7.2 or 6.2) or (aggressive and 4.8 or 3.9))
  local laneChangeDist = blocking and (aggressive and 24 or 28) or (aggressive and 42 or 48)
  local parameters = {
    minStTargetDist = blocking and (aggressive and 5.5 or 7.5) or (aggressive and 2.2 or 3.4),
    trafficWaitTime = 0,
    awarenessForceCoef = blocking and (aggressive and 2.6 or 2.25) or (aggressive and 1.9 or 1.55),
    edgeDist = blocking and (aggressive and -4.2 or -3.0) or (aggressive and -2.8 or -1.25),
    lookAheadKv = blocking and (aggressive and 0.52 or 0.42) or (aggressive and 0.78 or 0.55),
    throttleKp = blocking and (aggressive and 0.38 or 0.24) or (aggressive and 0.72 or 0.45),
    targetSpeedSmootherRate = blocking and (aggressive and 9 or 7) or (aggressive and 18 or 11),
    staticFrictionCoefMult = blocking and (aggressive and 0.88 or 0.78) or (aggressive and 0.96 or 0.88),
    turnForceCoef = blocking and (aggressive and 2.4 or 2.8) or (aggressive and 1.8 or 2.05),
    springForceIntegratorDispLim = blocking and (aggressive and 0.9 or 0.72) or (aggressive and 0.55 or 0.38)
  }

  veh:queueLuaCommand(
    'ai.setRacing(true); ai.setTrafficFilter(false); ai.setAggression(' .. tostring(aggression) ..
    '); ai.setAvoidCars("off"); ai.driveInLane("off"); ai.setParameters(' .. serialize(parameters) ..
    '); ai.setSpeedMode("set"); ai.setSpeed(' .. tostring(getOvertakeSpeed(settings, blocker)) ..
    '); ai.laneChange(nil, ' .. tostring(laneChangeDist) .. ', ' .. tostring(laneChangeDisp) .. ')'
  )
end

local function getForwardBlocker(veh, settings)
  if not veh or not map or not map.objects or not settings.overtakeTraffic or settings.avoidCars == false then return nil end

  local egoPos = veh:getPosition()
  local egoDir = veh:getDirectionVector()
  local egoUp = veh:getDirectionVectorUp()
  local egoRight = egoDir:cross(egoUp)
  if egoRight:length() > 0 then egoRight:normalize() end
  local egoVel = veh:getVelocity()
  local egoSpeed = vecLength(egoVel)
  local aggressive = settings.drivingMode == "aggressive"
  local maxForward = aggressive and 85 or BLOCKING_OBSTACLE_FORWARD
  local sameLaneWidth = aggressive and 2.35 or SAME_LANE_LATERAL
  local blockingLateral = aggressive and 3.75 or BLOCKING_OBSTACLE_LATERAL
  local closest
  local sameLaneObstacleCount = 0

  for id, data in pairs(map.objects) do
    if id ~= state.vehicleId and data and data.pos then
      local rel = data.pos - egoPos
      local forward = rel:dot(egoDir)
      if forward > 3 and forward < maxForward then
        local side = rel - egoDir * forward
        local lateral = side:length()
        local signedLateral = rel:dot(egoRight)
        local otherVel = data.vel
        local otherSpeed = vecLength(otherVel)
        local otherLongSpeed = otherVel and otherVel:dot(egoDir) or 0
        local dirDot = data.dirVec and data.dirVec:dot(egoDir) or (otherLongSpeed >= -0.5 and 1 or -1)
        local stationary = otherSpeed < BLOCKING_OBSTACLE_SPEED
        local crosswise = math.abs(dirDot) < 0.7
        local inSameLane = lateral < sameLaneWidth
        local blocking = stationary and ((crosswise and lateral < blockingLateral) or lateral < DIRECT_THREAT_LATERAL)
        local slowSameDirection = inSameLane and dirDot > -0.25 and (otherSpeed < 2.5 or otherLongSpeed < egoSpeed - 4 or (egoSpeed < 3 and forward < 18))

        if inSameLane and dirDot > -0.25 and forward < 70 and (otherSpeed < 3 or otherLongSpeed < egoSpeed - 3) then
          sameLaneObstacleCount = sameLaneObstacleCount + 1
        end

        if (blocking or slowSameDirection) and (not closest or forward < closest.forward or (blocking and not closest.blocking)) then
          local passSide = blocking
            and choosePassSide(id, signedLateral, egoPos, egoDir, egoRight, forward)
            or getPassSideFromLateral(signedLateral)
          closest = {
            id = id,
            forward = forward,
            lateral = lateral,
            signedLateral = signedLateral,
            passSide = passSide,
            otherSpeed = otherSpeed,
            otherLongSpeed = otherLongSpeed,
            dirDot = dirDot,
            blocking = blocking
          }
        end
      end
    end
  end

  if closest and sameLaneObstacleCount >= 2 then
    closest.blocking = true
    closest.passSide = choosePassSide(closest.id, closest.signedLateral, egoPos, egoDir, egoRight, closest.forward)
  end

  return closest
end

local function getTrackedBlocker(veh)
  if not veh or not map or not map.objects or not state.overtakeAssist.blockerId then return nil end

  local data = map.objects[state.overtakeAssist.blockerId]
  if not data or not data.pos then return nil end

  local egoPos = veh:getPosition()
  local egoDir = veh:getDirectionVector()
  local egoUp = veh:getDirectionVectorUp()
  local egoRight = egoDir:cross(egoUp)
  if egoRight:length() > 0 then egoRight:normalize() end

  local rel = data.pos - egoPos
  local forward = rel:dot(egoDir)
  local side = rel - egoDir * forward
  local signedLateral = rel:dot(egoRight)
  local otherVel = data.vel

  return {
    id = state.overtakeAssist.blockerId,
    forward = forward,
    lateral = side:length(),
    signedLateral = signedLateral,
    passSide = state.overtakeAssist.side or getPassSideFromLateral(signedLateral),
    otherSpeed = vecLength(otherVel),
    otherLongSpeed = otherVel and otherVel:dot(egoDir) or 0,
    blocking = state.overtakeAssist.blocking
  }
end

local function beginOvertakeAssist(veh, settings, blocker)
  if state.overtakeAssist.active then return end

  state.overtakeAssist.active = true
  state.overtakeAssist.clearTimer = 0
  state.overtakeAssist.age = 0
  state.overtakeAssist.commandTimer = 0
  state.overtakeAssist.blockerId = blocker and blocker.id or nil
  state.overtakeAssist.side = (blocker and blocker.passSide) or getPreferredOvertakeSide()
  state.overtakeAssist.lastBlockerForward = blocker and blocker.forward or nil
  state.overtakeAssist.blocking = blocker and blocker.blocking == true
  state.emergencyBrake = false
  state.status = "overtaking"
  applyOvertakeProfile(veh, settings, blocker)
  triggerUiState()
end

local function endOvertakeAssist(veh, settings)
  if not state.overtakeAssist.active then return end

  resetOvertakeAssist()
  state.status = "driving"
  applyDrivingProfile(veh, getDrivingProfile(settings))
  triggerUiState()
end

local function getForwardTrafficThreat(veh, settings)
  if not veh or not map or not map.objects then return nil end

  local egoPos = veh:getPosition()
  local egoDir = veh:getDirectionVector()
  local egoUp = veh:getDirectionVectorUp()
  local egoRight = egoDir:cross(egoUp)
  if egoRight:length() > 0 then egoRight:normalize() end
  local egoVel = veh:getVelocity()
  local egoSpeed = egoVel and egoVel:len() or 0
  local egoLongSpeed = egoVel and egoVel:dot(egoDir) or egoSpeed
  local egoLatSpeed = egoVel and egoVel:dot(egoRight) or 0
  local aggressive = settings.drivingMode == "aggressive"
  local assisting = state.overtakeAssist.active
  local maxForward = assisting and (aggressive and 42 or 44) or (aggressive and 48 or 44)
  local overlapLateral = assisting and (state.overtakeAssist.blocking and 1.95 or DIRECT_THREAT_LATERAL) or (aggressive and 1.55 or DIRECT_THREAT_LATERAL)
  local panicForward = assisting and (state.overtakeAssist.blocking and 13 or (aggressive and 6.5 or 8)) or (aggressive and 4.8 or 6.5)
  local panicTtc = assisting and (aggressive and 0.65 or 0.9) or (aggressive and 0.45 or 0.75)
  local closest

  for id, data in pairs(map.objects) do
    if id ~= state.vehicleId and data and data.pos then
      local rel = data.pos - egoPos
      local forward = rel:dot(egoDir)
      if forward > -3 and forward < math.max(maxForward, CUTIN_THREAT_FORWARD) then
        local side = rel - egoDir * forward
        local lateral = side:length()
        local signedLateral = rel:dot(egoRight)
        local otherVel = data.vel
        local otherAbsSpeed = vecLength(otherVel)
        local otherLongSpeed = otherVel and otherVel:dot(egoDir) or 0
        local otherLatSpeed = otherVel and otherVel:dot(egoRight) or 0
        local lateralSpeed = otherLatSpeed - egoLatSpeed
        local dirDot = data.dirVec and data.dirVec:dot(egoDir) or (otherLongSpeed >= -0.5 and 1 or -1)
        local crosswise = math.abs(dirDot) < 0.7
        local stationaryBlock = otherAbsSpeed < BLOCKING_OBSTACLE_SPEED and ((crosswise and lateral < BLOCKING_OBSTACLE_LATERAL) or lateral < DIRECT_THREAT_LATERAL)
        local movingIntoLane = math.abs(signedLateral) > DIRECT_THREAT_LATERAL and signedLateral * lateralSpeed < -CUTIN_LATERAL_SPEED
        local timeToLane = movingIntoLane and math.abs(signedLateral) / math.max(math.abs(lateralSpeed), 0.1) or math.huge
        local futureForward = forward + (otherLongSpeed - egoLongSpeed) * math.min(timeToLane, CUTIN_THREAT_TIME)
        local cutInThreat = movingIntoLane and timeToLane < CUTIN_THREAT_TIME and futureForward > -4 and futureForward < CUTIN_THREAT_FORWARD
        local directThreat = lateral < overlapLateral
        if directThreat or stationaryBlock or cutInThreat then
          local closingSpeed = egoSpeed - otherLongSpeed
          local ttc = forward / math.max(closingSpeed, 0.1)
          if cutInThreat or (stationaryBlock and forward < 22) or forward < panicForward or (directThreat and closingSpeed > 7 and ttc < panicTtc) then
            if not closest or forward < closest.forward then
              local passSide = cutInThreat
                and (signedLateral < 0 and 1 or -1)
                or choosePassSide(id, signedLateral, egoPos, egoDir, egoRight, forward)
              closest = {
                id = id,
                forward = forward,
                lateral = lateral,
                signedLateral = signedLateral,
                passSide = passSide,
                closingSpeed = closingSpeed,
                ttc = ttc,
                blocking = stationaryBlock,
                evasive = cutInThreat,
                timeToLane = timeToLane,
                lateralSpeed = lateralSpeed
              }
            end
          end
        end
      end
    end
  end

  return closest
end

local function applyTrafficEmergencyBrake(veh, settings, threat)
  if veh then
    local crawlSpeed = 0
    local command = 'ai.setSpeedMode("set"); ai.setSpeed(0)'
    if threat and (state.overtakeAssist.active or threat.evasive or threat.blocking) and threat.forward > 2.5 then
      local aggressive = settings and settings.drivingMode == "aggressive"
      local blocking = threat.blocking or state.overtakeAssist.blocking
      local passSide = threat.passSide or state.overtakeAssist.side or getPreferredOvertakeSide()
      local emergency = threat.evasive == true
      local laneChangeDisp = passSide * (emergency and (aggressive and 8.2 or 7.4) or (blocking and (aggressive and 7.4 or 6.4) or (aggressive and 4.6 or 3.5)))
      local laneChangeDist = emergency and 10 or (blocking and 16 or 14)
      crawlSpeed = emergency and (aggressive and 11 or 8.5) or (blocking and (aggressive and 2.2 or 1.4) or (aggressive and 3.5 or 2.5))
      if (blocking and threat.forward < 6) or (emergency and threat.forward < 4.5) then
        crawlSpeed = 0
      end
      command = 'ai.setRacing(true); ai.setTrafficFilter(false); ai.setAvoidCars("off"); ai.driveInLane("off"); ai.setSpeedMode("set"); ai.setSpeed(' .. tostring(crawlSpeed) ..
        '); ai.laneChange(nil, ' .. tostring(laneChangeDist) .. ', ' .. tostring(laneChangeDisp) .. ')'
    end
    veh:queueLuaCommand(command)
  end
end

local function restoreTrafficSpeed(veh, settings)
  if veh then
    releaseAiParkingBrake(veh)
    applyDrivingProfile(veh, getDrivingProfile(settings))
  end
end

local function getSlowRecoverySpeed(settings)
  if settings and settings.speedMode == "fixed" then
    return clamp((settings.fixedSpeedKmh or 80) / 3.6 * 0.42, 5.5, settings.drivingMode == "aggressive" and 18 or 14)
  end

  return settings and settings.drivingMode == "aggressive" and 8.5 or 6.5
end

local function updateTrafficGuard(veh, settings, dtReal)
  if not veh or not state.active or state.stopping then return end
  if settings.avoidCars == false then
    stopHighBeamFlash(veh)
    stopTrafficHorn(veh)
    state.slowRecoveryTimer = 0
    return
  end
  dtReal = dtReal or 0

  local blocker = getForwardBlocker(veh, settings)
  local trackedBlocker = state.overtakeAssist.active and getTrackedBlocker(veh) or nil
  local overtakeTarget = blocker or trackedBlocker
  local egoSpeed = vecLength(veh:getVelocity())
  local shouldFlash = overtakeTarget and overtakeTarget.forward > 4 and overtakeTarget.forward < HIGHBEAM_FLASH_RANGE and
    not state.emergencyBrake and
    (overtakeTarget.blocking or (overtakeTarget.otherLongSpeed or 0) < egoSpeed - 2 or (overtakeTarget.otherSpeed or 0) < 3)
  updateHighBeamFlash(veh, shouldFlash == true, dtReal)
  local shouldHonk = overtakeTarget and overtakeTarget.forward > 3.5 and overtakeTarget.forward < TRAFFIC_HORN_RANGE and
    not state.emergencyBrake and
    egoSpeed > 3 and
    (overtakeTarget.blocking or (overtakeTarget.otherLongSpeed or 0) < egoSpeed - 2.5 or (overtakeTarget.otherSpeed or 0) < 2.5)
  updateTrafficHorn(veh, shouldHonk == true, dtReal)

  if blocker then
    local blockerChanged = state.overtakeAssist.blockerId ~= blocker.id
    state.overtakeAssist.timer = state.overtakeAssist.timer + dtReal
    state.overtakeAssist.clearTimer = 0
    state.overtakeAssist.blockerId = blocker.id
    state.overtakeAssist.lastBlockerForward = blocker.forward
    state.overtakeAssist.blocking = blocker.blocking == true
    if blockerChanged or not state.overtakeAssist.active then
      state.overtakeAssist.side = blocker.passSide or getPreferredOvertakeSide()
    end

    if not state.overtakeAssist.active and (state.overtakeAssist.timer >= OVERTAKE_TRIGGER_TIME or blocker.forward < 34) then
      beginOvertakeAssist(veh, settings, blocker)
    end
  else
    state.overtakeAssist.timer = math.max(0, state.overtakeAssist.timer - dtReal * 2)
    if state.overtakeAssist.active then
      local trackedStillAhead = trackedBlocker and trackedBlocker.forward > OVERTAKE_PASS_CLEAR_FORWARD and trackedBlocker.forward < OVERTAKE_TRACK_MAX_FORWARD
      local holdingMinimum = state.overtakeAssist.age < OVERTAKE_MIN_HOLD_TIME
      if trackedStillAhead or holdingMinimum then
        state.overtakeAssist.clearTimer = 0
      else
        state.overtakeAssist.clearTimer = state.overtakeAssist.clearTimer + dtReal
      end
    end
  end

  if state.overtakeAssist.active then
    state.overtakeAssist.age = state.overtakeAssist.age + dtReal
    state.overtakeAssist.commandTimer = state.overtakeAssist.commandTimer + dtReal
    if trackedBlocker then
      state.overtakeAssist.lastBlockerForward = trackedBlocker.forward
    end

    if state.overtakeAssist.commandTimer >= OVERTAKE_REISSUE_INTERVAL then
      state.overtakeAssist.commandTimer = 0
      if not state.emergencyBrake then
        applyOvertakeProfile(veh, settings, overtakeTarget)
      end
    end

    if state.overtakeAssist.clearTimer >= OVERTAKE_CLEAR_TIME or state.overtakeAssist.age >= OVERTAKE_MAX_TIME then
      endOvertakeAssist(veh, settings)
    end
  end

  local threat = getForwardTrafficThreat(veh, settings)
  if threat then
    applyTrafficEmergencyBrake(veh, settings, threat)
    if not state.emergencyBrake then
      state.emergencyBrake = true
      state.status = "blockedTraffic"
      triggerUiState()
    end
  elseif state.emergencyBrake then
    state.emergencyBrake = false
    state.status = state.overtakeAssist.active and "overtaking" or "driving"
    if state.overtakeAssist.active then
      applyOvertakeProfile(veh, settings)
    else
      restoreTrafficSpeed(veh, settings)
    end
    triggerUiState()
  end

  local clearRoadButCrawling = not threat and
    not blocker and
    not trackedBlocker and
    not state.emergencyBrake and
    not state.overtakeAssist.active and
    (state.lastRouteDistance or math.huge) > 80 and
    egoSpeed > 0.35 and
    egoSpeed < getSlowRecoverySpeed(settings)

  if clearRoadButCrawling then
    state.slowRecoveryTimer = state.slowRecoveryTimer + dtReal
  else
    state.slowRecoveryTimer = 0
  end

  if state.slowRecoveryTimer >= SLOW_RECOVERY_TIME then
    state.slowRecoveryTimer = 0
    restoreTrafficSpeed(veh, settings)
  end
end

function startAutopilot(silent)
  local settings = getSettings()
  state.stopping = false
  state.stopTimer = 0
  state.stopCommandTimer = 0
  state.emergencyBrake = false
  state.routeRecovering = false
  state.routeRecoverTimer = 0
  state.routeStallTimer = 0
  state.slowRecoveryTimer = 0

  if not settings.enabled then
    state.status = "disabled"
    message("disabled", "warning")
    triggerUiState()
    return getUiState()
  end

  local veh = getPlayerVehicle()
  if not veh then
    state.status = "noVehicle"
    message("noVehicle", "warning")
    triggerUiState()
    return getUiState()
  end
  stopHighBeamFlash(veh)
  stopTrafficHorn(veh)

  local routePlanner = getRoutePlanner()
  if not routePlanner then
    state.status = "noRoute"
    message("noRoute", "warning")
    triggerUiState()
    return getUiState()
  end

  if routePlanner.trackVehicle then
    routePlanner:trackVehicle(veh)
  end

  local path = routePlanner.path
  local aiPath = getAiPath(path, veh)
  if not aiPath or not aiPath[1] then
    state.status = "noRoute"
    message("noAiRoute", "warning")
    triggerUiState()
    return getUiState()
  end

  local profile = getDrivingProfile(settings)
  local args = {
    wpTargetList = aiPath,
    noOfLaps = 1,
    aggression = profile.aggression,
    avoidCars = profile.avoidCars,
    driveInLane = profile.driveInLane,
    routeSpeedMode = profile.routeSpeedMode
  }

  if profile.routeSpeed then
    args.routeSpeed = profile.routeSpeed
  end

  releaseAiParkingBrake(veh)
  veh:queueLuaCommand("ai.driveUsingPath(" .. serialize(args) .. ")")
  applyDrivingProfile(veh, profile)

  state.active = true
  state.vehicleId = veh:getID()
  state.destinationPos = path[#path] and vec3(path[#path].pos) or nil
  state.lastRouteDistance = path[1] and path[1].distToTarget or nil
  state.status = "driving"

  if not silent then
    message("autopilotStarted")
  end
  triggerUiState()
  return getUiState()
end

local function applyUiSettings(newSettings)
  local merged = copyTable(getSettings())
  if type(newSettings) == "table" then
    for key, value in pairs(newSettings) do
      merged[key] = value
    end
  end

  state.settings = sanitizeSettings(merged)
  saveSettings()

  if state.active then
    local veh = state.vehicleId and getObjectByID(state.vehicleId) or getPlayerVehicle()
    if veh then
      if state.overtakeAssist.active then
        applyOvertakeProfile(veh, state.settings)
      else
        applyDrivingProfile(veh, getDrivingProfile(state.settings))
      end
    end
  end

  triggerUiState()
  return getUiState()
end

local function resetUiSettings()
  state.settings = sanitizeSettings(DEFAULT_SETTINGS)
  saveSettings()
  triggerUiState()
  return getUiState()
end

local function requestUiState()
  return getUiState()
end

local function onUpdate(dtReal)
  dtReal = dtReal or 0
  state.uiTimer = state.uiTimer + dtReal

  if state.stopping then
    local veh = state.vehicleId and getObjectByID(state.vehicleId) or getPlayerVehicle()
    state.stopTimer = state.stopTimer + dtReal
    state.stopCommandTimer = state.stopCommandTimer + dtReal
    if veh then
      if state.stopCommandTimer >= STOP_REISSUE_INTERVAL then
        state.stopCommandTimer = 0
        queueAiStop(veh)
      end
      local speed = veh:getVelocity() and veh:getVelocity():len() or 0
      if speed <= STOP_SPEED_THRESHOLD or (state.stopTimer >= STOP_TIMEOUT and speed <= FORCE_PARK_MAX_SPEED) then
        finishStop(veh)
        triggerUiState()
      end
    else
      finishStop(nil)
      state.status = "noVehicle"
      triggerUiState()
    end
  end

  if state.active then
    local veh = state.vehicleId and getObjectByID(state.vehicleId) or getPlayerVehicle()
    if state.routeRecovering then
      state.routeRecoverTimer = state.routeRecoverTimer + dtReal
    end

    if not veh then
      state.active = false
      state.vehicleId = nil
      state.destinationPos = nil
      state.status = "noVehicle"
      triggerUiState()
    else
      local routeInfo = getRouteInfo()
      if not routeInfo.hasRoute then
        local directDistance = state.destinationPos and veh:getPosition():distance(state.destinationPos) or math.huge
        local routeWasFar = (state.lastRouteDistance or math.huge) > ARRIVAL_ROUTE_DISTANCE
        if state.destinationPos and directDistance <= ARRIVAL_DISTANCE then
          beginStop(false, false, "arriving", "autopilotArrived", "arrived")
        elseif routeWasFar and state.routeRecoverTimer < 4 and recoverNavigationRoute() then
          state.status = "driving"
          triggerUiState()
        else
          beginStop(false, true, "noRoute", nil, "noRoute")
        end
      elseif hasArrivedAtDestination(veh, routeInfo) then
        beginStop(false, false, "arriving", "autopilotArrived", "arrived")
      elseif state.routeRecovering then
        state.routeRecovering = false
        state.routeRecoverTimer = 0
        state.routeStallTimer = 0
        startAutopilot(true)
      else
        state.lastRouteDistance = routeInfo.routeDistance
        local speed = veh:getVelocity() and veh:getVelocity():len() or 0
        local stalledFarFromFinish = routeInfo.routeDistance > ARRIVAL_ROUTE_DISTANCE and
          state.status == "driving" and
          not state.emergencyBrake and
          not state.overtakeAssist.active and
          speed < 0.25

        if stalledFarFromFinish then
          state.routeStallTimer = state.routeStallTimer + dtReal
        else
          state.routeStallTimer = 0
        end

        if state.routeStallTimer >= 3 then
          state.routeStallTimer = 0
          startAutopilot(true)
        else
          updateTrafficGuard(veh, getSettings(), dtReal)
        end
      end
    end
  end

  if state.uiTimer >= UI_UPDATE_INTERVAL then
    state.uiTimer = 0
    local signature = buildRouteSignature()
    if signature ~= state.lastSignature then
      state.lastSignature = signature
      triggerUiState()
    end
  end
end

local function onInit()
  getSettings()
  triggerUiState()
end

local function onClientEndMission()
  if state.active then
    stopAutopilot(false, true)
  end
end

local function onVehicleSwitched()
  if state.active then
    state.status = "vehicleChanged"
    stopAutopilot(false, true)
  else
    triggerUiState()
  end
end

M.onInit = onInit
M.onUpdate = onUpdate
M.onClientEndMission = onClientEndMission
M.onVehicleSwitched = onVehicleSwitched

M.requestUiState = requestUiState
M.startAutopilot = startAutopilot
M.stopAutopilot = stopAutopilot
M.applyUiSettings = applyUiSettings
M.resetUiSettings = resetUiSettings

return M
