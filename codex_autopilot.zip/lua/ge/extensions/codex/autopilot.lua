local M = {}

local SETTINGS_FILE = "/settings/CodexAutopilot.json"
local MESSAGE_CATEGORY = "codexAutopilot"
local ARRIVAL_DISTANCE = 28
local UI_UPDATE_INTERVAL = 0.25
local MAX_FIXED_SPEED_KMH = 500
local STOP_SPEED_THRESHOLD = 0.45
local STOP_TIMEOUT = 12
local STOP_REISSUE_INTERVAL = 1.25
local FORCE_PARK_MAX_SPEED = 2

local DEFAULT_SETTINGS = {
  enabled = true,
  hudVisible = true,
  drivingMode = "normal",
  speedMode = "adaptive",
  fixedSpeedKmh = 80,
  aggression = 0.3,
  avoidCars = true,
  driveInLane = true,
  clearRouteOnStop = false
}

local TEXT = {
  en = {
    autopilotStarted = "Autopilot started",
    autopilotStopped = "Autopilot stopped",
    autopilotArrived = "Autopilot arrived",
    disabled = "Autopilot is disabled in settings",
    noVehicle = "Autopilot: no player vehicle",
    noRoute = "Autopilot: set a route on the map first",
    noAiRoute = "Autopilot: could not build an AI route"
  },
  ru = {
    autopilotStarted = "Автопилот запущен",
    autopilotStopped = "Автопилот остановлен",
    autopilotArrived = "Автопилот прибыл",
    disabled = "Автопилот отключен в настройках",
    noVehicle = "Автопилот: нет машины игрока",
    noRoute = "Автопилот: сначала поставь маршрут на карте",
    noAiRoute = "Автопилот: не удалось построить маршрут для AI"
  }
}

local state = {
  settings = nil,
  active = false,
  vehicleId = nil,
  destinationPos = nil,
  status = "idle",
  uiTimer = 0,
  lastSignature = nil,
  stopping = false,
  stopTimer = 0,
  stopCommandTimer = 0,
  stopClearRoute = false,
  stopSilent = false,
  stopMessage = nil,
  stopFinalStatus = "stopped",
  emergencyBrake = false
}

local function clamp(value, low, high)
  value = tonumber(value) or low
  return math.min(high, math.max(low, value))
end

local function copyTable(source)
  local result = {}
  for key, value in pairs(source or {}) do
    result[key] = value
  end
  return result
end

local function sanitizeSettings(candidate)
  candidate = type(candidate) == "table" and candidate or {}

  return {
    enabled = candidate.enabled ~= false,
    hudVisible = candidate.hudVisible ~= false,
    drivingMode = candidate.drivingMode == "aggressive" and "aggressive" or "normal",
    speedMode = candidate.speedMode == "fixed" and "fixed" or "adaptive",
    fixedSpeedKmh = clamp(candidate.fixedSpeedKmh, 5, MAX_FIXED_SPEED_KMH),
    aggression = clamp(candidate.aggression, 0.2, 2),
    avoidCars = candidate.avoidCars ~= false,
    driveInLane = candidate.driveInLane ~= false,
    clearRouteOnStop = candidate.clearRouteOnStop == true
  }
end

local function getSettings()
  if not state.settings then
    state.settings = sanitizeSettings(jsonReadFile(SETTINGS_FILE) or DEFAULT_SETTINGS)
  end
  return state.settings
end

local function saveSettings()
  state.settings = sanitizeSettings(state.settings)
  jsonWriteFile(SETTINGS_FILE, state.settings, true)
end

local function getLocale()
  if settings and settings.getValue then
    local ok, language = pcall(function()
      return settings.getValue("uiLanguage") or settings.getValue("userLanguageSelected") or settings.getValue("userLanguage")
    end)
    if ok and language and language ~= "" then return language end
  end

  if Lua and Lua.getSelectedLanguage then
    local ok, language = pcall(function() return Lua:getSelectedLanguage() end)
    if ok and language then return language end
  end
  return "en-US"
end

local function getLanguageKey()
  local locale = string.lower(tostring(getLocale() or "en-US"))
  return string.sub(locale, 1, 2) == "ru" and "ru" or "en"
end

local function tr(key)
  local language = getLanguageKey()
  return (TEXT[language] and TEXT[language][key]) or TEXT.en[key] or tostring(key)
end

local function message(key, category)
  ui_message(tr(key), 5, MESSAGE_CATEGORY, category or "info")
end

local function getPlayerVehicle()
  return be and be:getPlayerVehicle(0) or nil
end

local function getRoutePlanner()
  if not core_groundMarkers or not core_groundMarkers.currentlyHasTarget then
    return nil
  end

  if not core_groundMarkers.currentlyHasTarget() then
    return nil
  end

  local routePlanner = core_groundMarkers.routePlanner
  if not routePlanner or not routePlanner.path or not routePlanner.path[2] then
    return nil
  end

  return routePlanner
end

local function getRouteInfo()
  local routePlanner = getRoutePlanner()
  if not routePlanner then
    return {
      hasRoute = false,
      routeDistance = 0,
      routeNodes = 0
    }
  end

  local path = routePlanner.path
  local last = path[#path]
  local distance = path[1].distToTarget or routePlanner:calcDistance() or 0

  return {
    hasRoute = true,
    routeDistance = distance,
    routeNodes = #path,
    destination = last and last.pos and {x = last.pos.x, y = last.pos.y, z = last.pos.z} or nil
  }
end

local function getUiState()
  local routeInfo = getRouteInfo()
  local vehicle = getPlayerVehicle()

  return {
    settings = getSettings(),
    active = state.active,
    stopping = state.stopping,
    status = state.status,
    hasRoute = routeInfo.hasRoute,
    routeDistance = routeInfo.routeDistance,
    routeNodes = routeInfo.routeNodes,
    destination = routeInfo.destination,
    vehicleId = vehicle and vehicle:getID() or nil,
    locale = getLocale()
  }
end

local function triggerUiState()
  guihooks.trigger("CodexAutopilotStateChanged", getUiState())
end

local function buildRouteSignature()
  local uiState = getUiState()
  local dest = uiState.destination
  local destKey = "none"
  if dest then
    destKey = string.format("%.1f:%.1f:%.1f", dest.x or 0, dest.y or 0, dest.z or 0)
  end

  return table.concat({
    tostring(uiState.active),
    tostring(uiState.stopping),
    tostring(uiState.status),
    tostring(uiState.hasRoute),
    tostring(uiState.vehicleId),
    tostring(uiState.routeNodes),
    tostring(math.floor((uiState.routeDistance or 0) + 0.5)),
    destKey
  }, "|")
end

local function getAiPath(path, veh)
  local aiPath = {}
  if not veh or not path then return nil end

  local firstWpAdded = false
  local vehPos = veh:getPosition()
  local vehFwd = veh:getDirectionVector()
  local prevDot = nil
  local prevWp = nil
  local startDist = path[1].distToTarget or 0

  for i, marker in ipairs(path) do
    if marker.wp then
      if not firstWpAdded then
        local toWp = marker.pos - vehPos
        if toWp:squaredLength() > 0.01 then
          toWp:normalize()
          local dot = toWp:dot(vehFwd)
          if prevDot and dot < prevDot and prevDot > 0 then
            table.insert(aiPath, prevWp)
            firstWpAdded = true
          end
          prevDot = dot
          prevWp = marker.wp
        end
      else
        table.insert(aiPath, marker.wp)
      end
    end
  end

  if not firstWpAdded and prevDot and prevDot > 0 and prevWp then
    table.insert(aiPath, prevWp)
    firstWpAdded = true
  end

  if not firstWpAdded then
    for _, marker in ipairs(path) do
      if marker.wp and startDist - (marker.distToTarget or 0) > 25 then
        table.insert(aiPath, marker.wp)
      end
    end
  end

  local compact = {}
  local lastWp = nil
  for _, wp in ipairs(aiPath) do
    if wp and wp ~= lastWp then
      table.insert(compact, wp)
      lastWp = wp
    end
  end

  return compact[1] and compact or nil
end

local function queueAiStop(veh)
  if veh then
    veh:queueLuaCommand('ai.setSpeedMode("set"); ai.setSpeed(0); ai.setState({mode = "stop"})')
  end
end

local function parkVehicleAndDisableAi(veh)
  if veh then
    veh:queueLuaCommand(
      'ai.setState({mode = "disabled"}); input.event("steering", 0, "FILTER_AI", nil, nil, nil, "ai"); input.event("throttle", 0, "FILTER_AI", nil, nil, nil, "ai"); input.event("brake", 0, "FILTER_AI", nil, nil, nil, "ai"); input.event("parkingbrake", 1, "FILTER_AI", nil, nil, nil, "ai")'
    )
  end
end

local function clearNavigationRoute()
  if freeroam_bigMapMode and freeroam_bigMapMode.setNavFocus then
    freeroam_bigMapMode.setNavFocus(nil)
  elseif core_groundMarkers and core_groundMarkers.setPath then
    core_groundMarkers.setPath(nil)
  end
end

local function finishStop(veh)
  parkVehicleAndDisableAi(veh)
  state.active = false
  state.stopping = false
  state.vehicleId = nil
  state.destinationPos = nil
  state.stopTimer = 0
  state.stopCommandTimer = 0
  state.emergencyBrake = false
  state.status = state.stopFinalStatus or "stopped"

  if state.stopClearRoute or getSettings().clearRouteOnStop then
    clearNavigationRoute()
  end

  if not state.stopSilent and state.stopMessage then
    message(state.stopMessage)
  end

  state.stopClearRoute = false
  state.stopSilent = false
  state.stopMessage = nil
  state.stopFinalStatus = "stopped"
end

local function beginStop(clearRoute, silent, status, stopMessage, finalStatus)
  local veh = state.vehicleId and getObjectByID(state.vehicleId) or getPlayerVehicle()
  state.active = false
  state.stopping = true
  state.stopTimer = 0
  state.stopCommandTimer = 0
  state.stopClearRoute = clearRoute == true
  state.stopSilent = silent == true
  state.stopMessage = stopMessage
  state.stopFinalStatus = finalStatus or "stopped"
  state.status = status or "stopping"

  if veh then
    queueAiStop(veh)
  else
    finishStop(nil)
    state.status = "noVehicle"
  end

  triggerUiState()
  return getUiState()
end

local function stopAutopilot(clearRoute, silent)
  if state.stopping then
    return getUiState()
  end

  return beginStop(clearRoute, silent, "stopping", "autopilotStopped")
end

local startAutopilot

local function getDrivingProfile(settings)
  local aggressive = settings.drivingMode == "aggressive"

  if aggressive then
    return {
      aggressive = true,
      aggression = math.max(settings.aggression, 1.75),
      avoidCars = "on",
      driveInLane = "off",
      routeSpeedMode = "set",
      routeSpeed = ((settings.speedMode == "fixed" and settings.fixedSpeedKmh) or MAX_FIXED_SPEED_KMH) / 3.6,
      parameters = {
        minStTargetDist = 2,
        trafficWaitTime = 0.2,
        awarenessForceCoef = 1.15,
        edgeDist = -1.5,
        lookAheadKv = 0.9,
        throttleKp = 0.95,
        targetSpeedSmootherRate = 25,
        staticFrictionCoefMult = 1,
        turnForceCoef = 1.65
      }
    }
  end

  return {
    aggressive = false,
    aggression = settings.aggression,
    avoidCars = settings.avoidCars and "on" or "off",
    driveInLane = settings.driveInLane and "on" or "off",
    routeSpeedMode = settings.speedMode == "fixed" and "limit" or "legal",
    routeSpeed = settings.speedMode == "fixed" and settings.fixedSpeedKmh / 3.6 or nil,
    parameters = {
      minStTargetDist = 12,
      trafficWaitTime = 4,
      awarenessForceCoef = 0.8,
      edgeDist = 0.7,
      lookAheadKv = 0.45,
      throttleKp = 0.35,
      targetSpeedSmootherRate = 5,
      staticFrictionCoefMult = 0.82,
      turnForceCoef = 2.2
    }
  }
end

local function applyDrivingProfile(veh, profile)
  if not veh or not profile then return end

  veh:queueLuaCommand("ai.setAggression(" .. tostring(profile.aggression) .. ")")
  veh:queueLuaCommand('ai.setAvoidCars("' .. profile.avoidCars .. '")')
  veh:queueLuaCommand('ai.driveInLane("' .. profile.driveInLane .. '")')
  veh:queueLuaCommand("ai.setParameters(" .. serialize(profile.parameters) .. ")")
  veh:queueLuaCommand('ai.setSpeedMode("' .. profile.routeSpeedMode .. '")')
  if profile.routeSpeed then
    veh:queueLuaCommand("ai.setSpeed(" .. tostring(profile.routeSpeed) .. ")")
  end
end

local function getForwardTrafficThreat(veh, settings)
  if not veh or not map or not map.objects then return nil end

  local egoPos = veh:getPosition()
  local egoDir = veh:getDirectionVector()
  local egoVel = veh:getVelocity()
  local egoSpeed = egoVel and egoVel:len() or 0
  local aggressive = settings.drivingMode == "aggressive"
  local maxForward = clamp(egoSpeed * (aggressive and 1.1 or 2.8) + (aggressive and 5 or 12), aggressive and 7 or 14, aggressive and 32 or 95)
  local maxLateral = aggressive and 3.3 or 5.8
  local closest

  for id, data in pairs(map.objects) do
    if id ~= state.vehicleId and data and data.pos then
      local rel = data.pos - egoPos
      local forward = rel:dot(egoDir)
      if forward > 0 and forward < maxForward then
        local side = rel - egoDir * forward
        local lateral = side:length()
        if lateral < maxLateral then
          local otherSpeed = data.vel and data.vel:dot(egoDir) or 0
          local closingSpeed = egoSpeed - otherSpeed
          if forward < (aggressive and 6 or 11) or closingSpeed > (aggressive and 7 or 1.5) then
            if not closest or forward < closest.forward then
              closest = {id = id, forward = forward, lateral = lateral, closingSpeed = closingSpeed}
            end
          end
        end
      end
    end
  end

  return closest
end

local function applyTrafficEmergencyBrake(veh)
  if veh then
    veh:queueLuaCommand('ai.setSpeedMode("set"); ai.setSpeed(0)')
  end
end

local function restoreTrafficSpeed(veh, settings)
  if veh then
    local profile = getDrivingProfile(settings)
    local command = 'ai.setSpeedMode("' .. profile.routeSpeedMode .. '")'
    if profile.routeSpeed then
      command = command .. '; ai.setSpeed(' .. tostring(profile.routeSpeed) .. ')'
    end
    veh:queueLuaCommand(command)
  end
end

local function updateTrafficGuard(veh, settings)
  if not veh or not state.active or state.stopping or settings.avoidCars == false then return end

  local threat = getForwardTrafficThreat(veh, settings)
  if threat then
    if not state.emergencyBrake then
      state.emergencyBrake = true
      state.status = "blockedTraffic"
      applyTrafficEmergencyBrake(veh)
      triggerUiState()
    end
  elseif state.emergencyBrake then
    state.emergencyBrake = false
    state.status = "driving"
    restoreTrafficSpeed(veh, settings)
    triggerUiState()
  end
end

function startAutopilot(silent)
  local settings = getSettings()
  state.stopping = false
  state.stopTimer = 0
  state.stopCommandTimer = 0
  state.emergencyBrake = false

  if not settings.enabled then
    state.status = "disabled"
    message("disabled", "warning")
    triggerUiState()
    return getUiState()
  end

  local veh = getPlayerVehicle()
  if not veh then
    state.status = "noVehicle"
    message("noVehicle", "warning")
    triggerUiState()
    return getUiState()
  end

  local routePlanner = getRoutePlanner()
  if not routePlanner then
    state.status = "noRoute"
    message("noRoute", "warning")
    triggerUiState()
    return getUiState()
  end

  if routePlanner.trackVehicle then
    routePlanner:trackVehicle(veh)
  end

  local path = routePlanner.path
  local aiPath = getAiPath(path, veh)
  if not aiPath or not aiPath[1] then
    state.status = "noRoute"
    message("noAiRoute", "warning")
    triggerUiState()
    return getUiState()
  end

  local profile = getDrivingProfile(settings)
  local args = {
    wpTargetList = aiPath,
    noOfLaps = 1,
    aggression = profile.aggression,
    avoidCars = profile.avoidCars,
    driveInLane = profile.driveInLane,
    routeSpeedMode = profile.routeSpeedMode
  }

  if profile.routeSpeed then
    args.routeSpeed = profile.routeSpeed
  end

  veh:queueLuaCommand("ai.driveUsingPath(" .. serialize(args) .. ")")
  applyDrivingProfile(veh, profile)

  state.active = true
  state.vehicleId = veh:getID()
  state.destinationPos = path[#path] and vec3(path[#path].pos) or nil
  state.status = "driving"

  if not silent then
    message("autopilotStarted")
  end
  triggerUiState()
  return getUiState()
end

local function applyUiSettings(newSettings)
  local merged = copyTable(getSettings())
  if type(newSettings) == "table" then
    for key, value in pairs(newSettings) do
      merged[key] = value
    end
  end

  state.settings = sanitizeSettings(merged)
  saveSettings()

  if state.active then
    local veh = state.vehicleId and getObjectByID(state.vehicleId) or getPlayerVehicle()
    if veh then
      applyDrivingProfile(veh, getDrivingProfile(state.settings))
    end
  end

  triggerUiState()
  return getUiState()
end

local function resetUiSettings()
  state.settings = sanitizeSettings(DEFAULT_SETTINGS)
  saveSettings()
  triggerUiState()
  return getUiState()
end

local function requestUiState()
  return getUiState()
end

local function onUpdate(dtReal)
  dtReal = dtReal or 0
  state.uiTimer = state.uiTimer + dtReal

  if state.stopping then
    local veh = state.vehicleId and getObjectByID(state.vehicleId) or getPlayerVehicle()
    state.stopTimer = state.stopTimer + dtReal
    state.stopCommandTimer = state.stopCommandTimer + dtReal
    if veh then
      if state.stopCommandTimer >= STOP_REISSUE_INTERVAL then
        state.stopCommandTimer = 0
        queueAiStop(veh)
      end
      local speed = veh:getVelocity() and veh:getVelocity():len() or 0
      if speed <= STOP_SPEED_THRESHOLD or (state.stopTimer >= STOP_TIMEOUT and speed <= FORCE_PARK_MAX_SPEED) then
        finishStop(veh)
        triggerUiState()
      end
    else
      finishStop(nil)
      state.status = "noVehicle"
      triggerUiState()
    end
  end

  if state.active then
    local veh = state.vehicleId and getObjectByID(state.vehicleId) or getPlayerVehicle()
    if not veh then
      state.active = false
      state.vehicleId = nil
      state.destinationPos = nil
      state.status = "noVehicle"
      triggerUiState()
    elseif state.destinationPos and veh:getPosition():distance(state.destinationPos) <= ARRIVAL_DISTANCE then
      beginStop(false, false, "arriving", "autopilotArrived", "arrived")
    elseif not getRoutePlanner() then
      beginStop(false, true, "noRoute", nil, "noRoute")
    else
      updateTrafficGuard(veh, getSettings())
    end
  end

  if state.uiTimer >= UI_UPDATE_INTERVAL then
    state.uiTimer = 0
    local signature = buildRouteSignature()
    if signature ~= state.lastSignature then
      state.lastSignature = signature
      triggerUiState()
    end
  end
end

local function onInit()
  getSettings()
  triggerUiState()
end

local function onClientEndMission()
  if state.active then
    stopAutopilot(false, true)
  end
end

local function onVehicleSwitched()
  if state.active then
    state.status = "vehicleChanged"
    stopAutopilot(false, true)
  else
    triggerUiState()
  end
end

M.onInit = onInit
M.onUpdate = onUpdate
M.onClientEndMission = onClientEndMission
M.onVehicleSwitched = onVehicleSwitched

M.requestUiState = requestUiState
M.startAutopilot = startAutopilot
M.stopAutopilot = stopAutopilot
M.applyUiSettings = applyUiSettings
M.resetUiSettings = resetUiSettings

return M
