var CODEX_AP_TEXT = {
  en: {
    mainMenuButton: "Autopilot Settings",
    startAutopilot: "Start Autopilot",
    stopAutopilot: "Stop Autopilot",
    stopping: "Stopping...",
    kicker: "Codex Autopilot",
    title: "Autopilot Settings",
    subtitle: "Route driving settings for the HUD autopilot button.",
    general: "General",
    enableAutopilot: "Enable autopilot",
    enableAutopilotCopy: "Allows the Start Autopilot button to control the current vehicle.",
    showHudButton: "Show HUD button",
    showHudButtonCopy: "Displays Start Autopilot when a map route exists.",
    clearRouteOnStop: "Clear route on stop",
    clearRouteOnStopCopy: "Removes the current map route when autopilot is stopped.",
    driving: "Driving",
    drivingMode: "Driving mode",
    drivingModeCopy: "Normal brakes earlier; Aggressive uses higher risk overtakes and may leave the lane.",
    "drivingMode.normal": "Normal",
    "drivingMode.aggressive": "Aggressive",
    speedMode: "Speed mode",
    speedModeCopy: "Adaptive follows road limits and traffic; fixed caps the route speed.",
    "speedMode.adaptive": "Adaptive",
    "speedMode.fixed": "Fixed limit",
    fixedSpeedLimit: "Fixed speed limit",
    fixedSpeedLimitCopy: "Maximum route speed in km/h.",
    aggression: "Aggression",
    aggressionCopy: "Lower is calmer; higher drives closer to the AI limits.",
    avoidVehicles: "Avoid other vehicles",
    avoidVehiclesCopy: "Uses BeamNG AI traffic awareness.",
    overtakeTraffic: "Overtake slower traffic",
    overtakeTrafficCopy: "Temporarily allows lane changes to pass stopped or slow vehicles.",
    driveInLane: "Drive in lane",
    driveInLaneCopy: "Prefers the legal side of two-way roads.",
    runtime: "Runtime",
    statusLabel: "Status",
    routeLabel: "Route",
    "route.ready": "ready",
    "route.notSet": "not set",
    resetDefaults: "Reset Defaults",
    back: "Back",
    "status.idle": "idle",
    "status.driving": "driving",
    "status.stopping": "stopping",
    "status.stopped": "stopped",
    "status.arriving": "arriving",
    "status.arrived": "arrived",
    "status.noVehicle": "no player vehicle",
    "status.noRoute": "no route",
    "status.disabled": "disabled",
    "status.blockedTraffic": "traffic ahead",
    "status.overtaking": "overtaking",
    "status.vehicleChanged": "vehicle changed"
  },
  ru: {
    mainMenuButton: "Настройки автопилота",
    startAutopilot: "Запустить автопилот",
    stopAutopilot: "Остановить автопилот",
    stopping: "Остановка...",
    kicker: "Codex Autopilot",
    title: "Настройки автопилота",
    subtitle: "Настройки движения по маршруту для кнопки автопилота в HUD.",
    general: "Основное",
    enableAutopilot: "Включить автопилот",
    enableAutopilotCopy: "Разрешает кнопке запуска управлять текущей машиной.",
    showHudButton: "Показывать кнопку HUD",
    showHudButtonCopy: "Показывает кнопку запуска, когда на карте есть маршрут.",
    clearRouteOnStop: "Очищать маршрут при остановке",
    clearRouteOnStopCopy: "Убирает текущий маршрут с карты после остановки автопилота.",
    driving: "Вождение",
    drivingMode: "Режим вождения",
    drivingModeCopy: "Normal тормозит раньше; Aggressive рискованнее обгоняет и может выезжать из полосы.",
    "drivingMode.normal": "Normal",
    "drivingMode.aggressive": "Aggressive",
    speedMode: "Режим скорости",
    speedModeCopy: "Adaptive следует лимитам и трафику; Fixed ограничивает скорость маршрута.",
    "speedMode.adaptive": "Adaptive",
    "speedMode.fixed": "Fixed limit",
    fixedSpeedLimit: "Лимит fixed speed",
    fixedSpeedLimitCopy: "Максимальная скорость маршрута в км/ч.",
    aggression: "Агрессивность",
    aggressionCopy: "Ниже спокойнее; выше ближе к пределам AI.",
    avoidVehicles: "Избегать машины",
    avoidVehiclesCopy: "Использует штатную осторожность AI BeamNG к трафику.",
    overtakeTraffic: "Обгонять медленный трафик",
    overtakeTrafficCopy: "Временно разрешает перестроение, чтобы объехать стоящие или медленные машины.",
    driveInLane: "Держаться полосы",
    driveInLaneCopy: "Предпочитает правильную сторону дороги.",
    runtime: "Запуск",
    statusLabel: "Статус",
    routeLabel: "Маршрут",
    "route.ready": "готов",
    "route.notSet": "не задан",
    resetDefaults: "Сбросить",
    back: "Назад",
    "status.idle": "ожидание",
    "status.driving": "едет",
    "status.stopping": "останавливается",
    "status.stopped": "остановлен",
    "status.arriving": "прибывает",
    "status.arrived": "прибыл",
    "status.noVehicle": "нет машины игрока",
    "status.noRoute": "нет маршрута",
    "status.disabled": "отключен",
    "status.blockedTraffic": "трафик впереди",
    "status.overtaking": "обгоняет",
    "status.vehicleChanged": "машина изменена"
  }
}

function codexApLang(locale) {
  locale = String(locale || "en-US").toLowerCase()
  return locale.indexOf("ru") === 0 ? "ru" : "en"
}

function codexApText(key, locale) {
  var lang = codexApLang(locale)
  return (CODEX_AP_TEXT[lang] && CODEX_AP_TEXT[lang][key]) || CODEX_AP_TEXT.en[key] || key
}

function codexApAngularLocale($translate) {
  if ($translate && typeof $translate.use === "function" && $translate.use()) return $translate.use()
  if (window.i18nLanguageUsed) return window.i18nLanguageUsed
  if (window.beamng && window.beamng.language) return window.beamng.language
  return "en-US"
}

angular.module("codex_autopilot", [])

.config(["$stateProvider", function ($stateProvider) {
  $stateProvider.state("menu.codex_autopilot", {
    url: "/codex-autopilot/:mode",
    params: {
      mode: null,
    },
    templateUrl: "/ui/modModules/codex_autopilot/codex_autopilot.html",
    controller: "CodexAutopilotSettingsController as ap",
    backState: "BACK_TO_MENU",
  })
}])

.run(["$rootScope", "$compile", "$document", "$timeout", "$translate", function ($rootScope, $compile, $document, $timeout, $translate) {
  function ensureStylesheet() {
    if (document.getElementById("codex-autopilot-css")) return
    var link = document.createElement("link")
    link.id = "codex-autopilot-css"
    link.rel = "stylesheet"
    link.type = "text/css"
    link.href = "/ui/modModules/codex_autopilot/codex_autopilot.css"
    document.head.appendChild(link)
  }

  function installHud() {
    if (document.getElementById("codex-autopilot-hud-root")) return
    var scope = $rootScope.$new(true)
    var el = angular.element('<codex-autopilot-hud id="codex-autopilot-hud-root"></codex-autopilot-hud>')
    angular.element($document[0].body).append(el)
    $compile(el)(scope)
  }

  function addMainMenuButton(addButton) {
    if (typeof addButton !== "function") return
    addButton({
      title: codexApText("mainMenuButton", codexApAngularLocale($translate)),
      iconId: "road",
      action: "menu.codex_autopilot",
    })
  }

  function broadcastButtonRefresh() {
    if (window.bridge && window.bridge.events) {
      window.bridge.events.emit("BroadcastMainMenuButtons")
    }
  }

  $rootScope.$on("MainMenuButtons", function (event, addButton) {
    addMainMenuButton(addButton)
  })

  $rootScope.$on("$translateChangeSuccess", function () {
    broadcastButtonRefresh()
  })

  ensureStylesheet()
  $timeout(installHud, 0)
  $timeout(broadcastButtonRefresh, 0)
  $timeout(broadcastButtonRefresh, 500)
}])

.directive("codexAutopilotHud", [function () {
  return {
    restrict: "E",
    template:
      '<div class="codex-ap-hud" ng-if="hud.visible()">' +
        '<button class="codex-ap-button" ng-class="{active: hud.state.active || hud.state.stopping}" ng-click="hud.toggle()" ng-disabled="hud.busy || hud.state.stopping">' +
          '<span class="codex-ap-dot"></span>' +
          '<span>{{ hud.label() }}</span>' +
        '</button>' +
        '<div class="codex-ap-sub" ng-if="hud.state.routeDistance > 0">{{ hud.distanceText() }}</div>' +
      '</div>',
    controller: ["$scope", "$timeout", "$state", "$translate", function ($scope, $timeout, $state, $translate) {
      var vm = this
      var timer = null

      vm.busy = false
      vm.state = {
        active: false,
        hasRoute: false,
        routeDistance: 0,
        locale: codexApAngularLocale($translate),
        settings: {
          hudVisible: true
        }
      }

      function applyState(data) {
        if (!data) return
        vm.state = angular.extend({}, vm.state, data)
        vm.state.settings = angular.extend({hudVisible: true}, vm.state.settings || {}, data.settings || {})
        vm.state.locale = vm.state.locale || codexApAngularLocale($translate)
      }

      vm.t = function (key) {
        return codexApText(key, vm.state.locale || codexApAngularLocale($translate))
      }

      function requestSoon(delay) {
        if (timer) $timeout.cancel(timer)
        timer = $timeout(function () {
          vm.request()
          requestSoon(1000)
        }, delay)
      }

      vm.request = function () {
        bngApi.engineLua("extensions.codex_autopilot.requestUiState()", function (data) {
          $scope.$evalAsync(function () {
            applyState(data)
          })
        })
      }

      vm.visible = function () {
        var stateName = $state.current && $state.current.name
        return vm.state &&
          vm.state.settings &&
          vm.state.settings.enabled !== false &&
          vm.state.settings.hudVisible &&
          vm.state.hasRoute &&
          stateName !== "menu.codex_autopilot"
      }

      vm.label = function () {
        if (vm.state.stopping) return vm.t("stopping")
        return vm.state.active ? vm.t("stopAutopilot") : vm.t("startAutopilot")
      }

      vm.distanceText = function () {
        var meters = Number(vm.state.routeDistance) || 0
        if (meters >= 1000) return (meters / 1000).toFixed(1) + " km"
        return Math.round(meters) + " m"
      }

      vm.toggle = function () {
        vm.busy = true
        if (vm.state.stopping) return
        var cmd = vm.state.active
          ? "extensions.codex_autopilot.stopAutopilot(false)"
          : "extensions.codex_autopilot.startAutopilot()"

        bngApi.engineLua(cmd, function (data) {
          $scope.$evalAsync(function () {
            vm.busy = false
            applyState(data)
          })
        })
      }

      $scope.$on("CodexAutopilotStateChanged", function (event, data) {
        $scope.$evalAsync(function () {
          applyState(data)
        })
      })

      $scope.$on("$destroy", function () {
        if (timer) $timeout.cancel(timer)
      })

      vm.request()
      requestSoon(1000)
    }],
    controllerAs: "hud"
  }
}])

.controller("CodexAutopilotSettingsController", ["$scope", "$state", "$translate", function ($scope, $state, $translate) {
  var vm = this

  vm.loading = true
  vm.state = {
    locale: codexApAngularLocale($translate)
  }
  vm.data = {
    enabled: true,
    hudVisible: true,
    speedMode: "adaptive",
    drivingMode: "normal",
    fixedSpeedKmh: 80,
    aggression: 0.3,
    avoidCars: true,
    driveInLane: true,
    overtakeTraffic: true,
    clearRouteOnStop: false,
  }

  vm.speedModes = [
    {value: "adaptive"},
    {value: "fixed"},
  ]

  vm.drivingModes = [
    {value: "normal"},
    {value: "aggressive"},
  ]

  vm.t = function (key) {
    return codexApText(key, vm.state.locale || codexApAngularLocale($translate))
  }

  function applyState(data) {
    if (!data) return
    vm.loading = false
    vm.state = data
    vm.state.locale = vm.state.locale || codexApAngularLocale($translate)
    vm.data = angular.extend({}, vm.data, data.settings || {})
  }

  vm.request = function () {
    bngApi.engineLua("extensions.codex_autopilot.requestUiState()", function (data) {
      $scope.$evalAsync(function () {
        applyState(data)
      })
    })
  }

  vm.apply = function () {
    var payload = {
      enabled: !!vm.data.enabled,
      hudVisible: !!vm.data.hudVisible,
      drivingMode: vm.data.drivingMode === "aggressive" ? "aggressive" : "normal",
      speedMode: vm.data.speedMode === "fixed" ? "fixed" : "adaptive",
      fixedSpeedKmh: Number(vm.data.fixedSpeedKmh) || 80,
      aggression: Number(vm.data.aggression) || 0.3,
      avoidCars: !!vm.data.avoidCars,
      driveInLane: !!vm.data.driveInLane,
      overtakeTraffic: !!vm.data.overtakeTraffic,
      clearRouteOnStop: !!vm.data.clearRouteOnStop,
    }

    bngApi.engineLua("extensions.codex_autopilot.applyUiSettings(" + bngApi.serializeToLua(payload) + ")", function (data) {
      $scope.$evalAsync(function () {
        applyState(data)
      })
    })
  }

  vm.reset = function () {
    bngApi.engineLua("extensions.codex_autopilot.resetUiSettings()", function (data) {
      $scope.$evalAsync(function () {
        applyState(data)
      })
    })
  }

  vm.start = function () {
    bngApi.engineLua("extensions.codex_autopilot.startAutopilot()", function (data) {
      $scope.$evalAsync(function () {
        applyState(data)
      })
    })
  }

  vm.stop = function () {
    bngApi.engineLua("extensions.codex_autopilot.stopAutopilot(false)", function (data) {
      $scope.$evalAsync(function () {
        applyState(data)
      })
    })
  }

  vm.close = function () {
    var targetState = $state.params && $state.params.mode === "mainMenuOthers"
      ? "menu.mainmenu.others"
      : "menu.mainmenu"

    if (window.bngVue && window.bngVue.gotoGameState) {
      window.bngVue.gotoGameState(targetState, {tryAngularJS: true, blankAngularJS: true})
      return
    }

    $state.go("menu.mainmenu")
  }

  $scope.$on("CodexAutopilotStateChanged", function (event, data) {
    $scope.$evalAsync(function () {
      applyState(data)
    })
  })

  vm.request()
}])

export default true
